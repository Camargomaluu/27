$(document).ready(function(){
    
    $("#i_cep").mask("00000-000");

})